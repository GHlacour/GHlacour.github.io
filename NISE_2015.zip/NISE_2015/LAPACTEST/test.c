#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include "test.h"

int main(int argc, char *argv[])
{
  return;
}

// Diagonalize with LAPACK (destructive version)
void diagonalizeLPD(float *H,float *v,int N){
  int INFO,lwork;
  float *work,*Hcopy;
  int i,j;
  // Find lwork;
  lwork=-1;
  work=(float *)calloc(1,sizeof(float));
  ssyev_("V","U",&N,Hcopy,&N,v,work,&lwork,&INFO);
  lwork=work[0];
  //  printf("LAPACK work dimension %d\n",lwork);
  //  lwork=8*N;
  free(work);
  work=(float *)calloc(lwork,sizeof(float));
  Hcopy=(float *)calloc(N*N,sizeof(float));
  // Copy Hamiltonian
  for (i=0;i<N;i++){
    for (j=0;j<N;j++){
      Hcopy[i*N+j]=H[i*N+j]; 
    }
  }

  // Call LAPACK routine
  ssyev_("V","U",&N,Hcopy,&N,v,work,&lwork,&INFO);
  //  printf("LAPACK opt. %f %f\n",work[0],work[0]/N);
  if (INFO!=0){
    printf("Something went wrong trying to diagonalize a matrix...\n");
    exit(0);
  }

  // Move eigenvectors
  for (i=0;i<N;i++){
    for (j=0;j<N;j++){
      H[i*N+j]=Hcopy[j*N+i]; // Converting from FORTRAN format
    }
  }
  // Free space
  free(Hcopy),free(work);
  return;
}
