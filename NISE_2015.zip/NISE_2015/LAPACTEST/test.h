#include "lapack.h"
void diagonalizeLPD(float *H,float *v,int N);
