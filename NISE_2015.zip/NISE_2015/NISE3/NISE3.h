#ifndef _NISE2_
#define _NISE2_

#endif // _NISE2_
